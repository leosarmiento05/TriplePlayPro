package sas.lwcprosi.tripleplaypro;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    MediaPlayer mp = new MediaPlayer();
    MediaPlayer mr = new MediaPlayer();
    MediaPlayer mediaPlayer2 = new MediaPlayer();
    MediaPlayer mediaPlayer3 = new MediaPlayer();
    MediaPlayer mediaPlayer4 = new MediaPlayer();
    Button bCargar, bPlay, bPause, bStop;
    RadioButton Audio1, Audio2, Audio3, carga1, carga2, carga3, Audio4, carga4;
    TextView SalidaTexto;
    private final int PICKER = 1;
    private int State = 1;
    private final int Playing = 1;
    private final int Pausing = 2;
    int a=0,b=0,c=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bCargar = (Button) findViewById(R.id.bCargar);
        bPlay = (Button) findViewById(R.id.Play);
        bPause = (Button) findViewById(R.id.Pause);
        bCargar.setOnClickListener(this);
        bPlay.setOnClickListener(this);
        bPause.setOnClickListener(this);
        Audio1 = (RadioButton) findViewById(R.id.Audio_1);
        Audio2 = (RadioButton) findViewById(R.id.Audio_2);
        Audio3 = (RadioButton) findViewById(R.id.Audio_3);
        Audio4 = (RadioButton) findViewById(R.id.Audio_4);
        carga1=(RadioButton)findViewById(R.id.Audio_C1);
        carga2=(RadioButton)findViewById(R.id.Audio_C2);
        carga3=(RadioButton)findViewById(R.id.Audio_C3);
        carga4=(RadioButton)findViewById(R.id.Audio_C4);
        SalidaTexto = (TextView) findViewById(R.id.textView);
        SalidaTexto.setText("No hay audios cargados");

        /*mediaPlayer = MediaPlayer.create(this,R.raw.audio);
        mediaPlayer.setLooping(true);*/


    }

    private void PickFile() {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {

            startActivityForResult(Intent.createChooser(intent, "Seleccione un administrador de archivos"), PICKER);
        } catch (android.content.ActivityNotFoundException ex) {

        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        switch (requestCode) {

            case PICKER:
                if (resultCode == RESULT_OK) {
                    Uri FilePath1;
                    String FilePathAudio1, FilePathAudio2, FilePathAudio3, FilePathAudio4;
                    byte[] wav1 = new byte[0],wav2 = new byte[0],wav3 = new byte[0],wavFinal;
                    float wav3Float = 0,wav2Float=0,wav1Float=0;

                    try {

                        if (Audio1.isChecked()) {

                                FilePath1=null;
                                SalidaTexto.setText("");
                                FilePath1 = data.getData();
                                FilePathAudio1 = getRealPathFromURI(FilePath1);
                                mr.setDataSource(FilePathAudio1);
                                mr.prepare();
                                if (FilePathAudio1!=null){
                                    carga1.setBackgroundColor(Color.RED);
                                    a=1;
                                    bPlay.setEnabled(true);
                                    bPause.setEnabled(true);
                                    SalidaTexto.setText("");

                                }






                            /*wav1 = WavArray(FilePathAudio1);
                            wav1Float=bytearray2float(wav1);*/






                            /*FileInputStream Wav1 = new FileInputStream(FilePathAudio1);
                            int Data=Wav1.read();
                            SalidaTexto.setText(Data);*/
                            //byte[] dataA= new byte[(int) Wav1.length()];

                        }
                        File Wav1 = new File(String.valueOf(mediaPlayer3));

                        if (Audio2.isChecked()) {

                            SalidaTexto.setText("");
                            FilePath1 = data.getData();
                            FilePathAudio2 = getRealPathFromURI(FilePath1);
                            mediaPlayer2.setDataSource(FilePathAudio2);
                            mediaPlayer2.prepare();

                            if (FilePathAudio2!=null){
                                carga2.setBackgroundColor(Color.RED);
                                b=1;
                                bPlay.setEnabled(true);
                                bPause.setEnabled(true);

                                SalidaTexto.setText("");

                            }


                        }

                        if (Audio3.isChecked()) {

                            SalidaTexto.setText("");
                            FilePath1 = data.getData();
                            FilePathAudio3 = getRealPathFromURI(FilePath1);
                            mediaPlayer3.setDataSource(FilePathAudio3);
                            mediaPlayer3.prepare();

                            if (FilePathAudio3!=null){
                                carga3.setBackgroundColor(Color.RED);
                                c=1;
                                bPlay.setEnabled(true);
                                bPause.setEnabled(true);

                                SalidaTexto.setText("");
                            }
                            /*wav3 = WavArray(FilePathAudio3);
                            wav3Float=bytearray2float(wav3);*/

                        }
                        if (Audio4.isChecked()) {

                            SalidaTexto.setText("");
                            FilePath1 = data.getData();
                            FilePathAudio4 = getRealPathFromURI(FilePath1);
                            mediaPlayer4.setDataSource(FilePathAudio4);
                            mediaPlayer4.prepare();

                            if (FilePathAudio4!=null){
                                carga4.setBackgroundColor(Color.RED);
                                c=1;
                                bPlay.setEnabled(true);
                                bPause.setEnabled(true);

                                SalidaTexto.setText("");
                            }
                            /*wav3 = WavArray(FilePathAudio3);
                            wav3Float=bytearray2float(wav3);*/

                        }
                        if ((a+b+c)==1){

                        }
                        float WavFinal= wav3Float+wav1Float+wav2Float;

                           /* byte[]WavFinalByte=float2ByteArray(WavFinal);
                            String OUTPUT_FILE= Environment.getExternalStorageDirectory()+"/grabacionhardcore.3gpp";
                            escribirArchivo(WavFinalByte, OUTPUT_FILE);
                            mp.setDataSource(OUTPUT_FILE);
                            mp.prepare();




                        /*mediaPlayer2.prepare();
                        mediaPlayer3.prepare();*/
                        FilePathAudio1 = null;
                        FilePathAudio2 = null;
                        FilePathAudio3 = null;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
                break;

        }
    }

    public String getRealPathFromURI(Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Audio.Media.DATA};
            cursor = getApplicationContext().getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString((column_index));


        } finally {
            if (cursor != null) {
                cursor.close();

            }
        }
    }

    public void onClick(View v) {
        if (v == bCargar) {
            PickFile();

        } else {
            if (v == bPlay) {
                mr.start();

                mediaPlayer2.start();
                mediaPlayer3.start();
                mediaPlayer4.start();
                SalidaTexto.setText("Reproduciendo audios...");
            }
            if (v == bPause) {

                mr.pause();
                mediaPlayer2.pause();
                mediaPlayer3.pause();
                mediaPlayer4.pause();

                SalidaTexto.setText("Pausado...");



            }


        }
        ;
    }


    public byte[] WavArray(String Ruta) throws IOException {








        ByteArrayOutputStream out = new ByteArrayOutputStream();
            BufferedInputStream in = new BufferedInputStream(new FileInputStream(Ruta));

            int read;
            byte[] buff = new byte[1024];
            while ((read = in.read(buff)) > 0) {
                out.write(buff, 0, read);
            }
            out.flush();
            byte[] audioBytes = out.toByteArray();




        return audioBytes;
    }
    public static float bytearray2float(byte[] b) {
        ByteBuffer buf = ByteBuffer.wrap(b);
        return buf.getFloat();
    }
    public static byte [] float2ByteArray (float value)
    {
        return ByteBuffer.allocate(4).putFloat(value).array();
    }
    public static boolean escribirArchivo(byte[] fileBytes, String archivoDestino){
        boolean correcto = false;
        try {
            OutputStream out = new FileOutputStream(archivoDestino);
            out.write(fileBytes);
            out.close();
            correcto = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correcto;

    }

}





